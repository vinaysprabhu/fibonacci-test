#!/usr/bin/env python
# -*- coding: utf-8 -*-
#!//anaconda/bin/python
#!flask/bin/python
from app import app
app.run(debug=True)